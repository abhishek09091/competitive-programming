package com.news.timeline.utils;

import com.news.timeline.models.Feed;

import java.util.Comparator;

public class SortByFeedId implements Comparator<Feed> {

    @Override
    public int compare(Feed o1, Feed o2) {
        if(o1.getFeedId() < o2.getFeedId()) return 1;
        if(o1.getFeedId() > o2.getFeedId()) return -1;
        else return 0;
    }
}
